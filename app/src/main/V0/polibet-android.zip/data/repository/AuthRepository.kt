package com.epn.polibet.data.repository

import com.epn.polibet.data.models.LoginRequest
import com.epn.polibet.data.models.RegisterRequest
import com.epn.polibet.data.models.User
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuthRepository {
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()
    
    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()
    
    // Simulación de base de datos de usuarios
    private val registeredUsers = mutableListOf<User>()
    
    suspend fun login(request: LoginRequest): Result<User> {
        delay(1000) // Simular llamada de red
        
        // Validación básica
        if (request.email.isBlank() || request.password.isBlank()) {
            return Result.failure(Exception("Email y contraseña son requeridos"))
        }
        
        // Buscar usuario registrado o crear uno de prueba
        val user = registeredUsers.find { it.email == request.email }
            ?: User(
                id = "user_${System.currentTimeMillis()}",
                email = request.email,
                username = request.email.substringBefore("@"),
                fullName = "Usuario Demo"
            )
        
        _currentUser.value = user
        _isAuthenticated.value = true
        
        return Result.success(user)
    }
    
    suspend fun register(request: RegisterRequest): Result<User> {
        delay(1000) // Simular llamada de red
        
        // Validaciones
        if (request.email.isBlank() || request.password.isBlank()) {
            return Result.failure(Exception("Todos los campos son requeridos"))
        }
        
        if (request.password != request.confirmPassword) {
            return Result.failure(Exception("Las contraseñas no coinciden"))
        }
        
        if (request.password.length < 6) {
            return Result.failure(Exception("La contraseña debe tener al menos 6 caracteres"))
        }
        
        // Verificar si el usuario ya existe
        if (registeredUsers.any { it.email == request.email }) {
            return Result.failure(Exception("El email ya está registrado"))
        }
        
        val newUser = User(
            id = "user_${System.currentTimeMillis()}",
            email = request.email,
            username = request.username,
            fullName = request.fullName
        )
        
        registeredUsers.add(newUser)
        _currentUser.value = newUser
        _isAuthenticated.value = true
        
        return Result.success(newUser)
    }
    
    fun logout() {
        _currentUser.value = null
        _isAuthenticated.value = false
    }
}
