package com.epn.polibet.data.repository

import com.epn.polibet.data.models.Event
import com.epn.polibet.data.models.EventOdds
import com.epn.polibet.data.models.EventStatus
import com.epn.polibet.data.models.Sport
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class SportsRepository {
    
    suspend fun getSports(): List<Sport> {
        delay(500) // Simular llamada de red
        return listOf(
            Sport("football", "Fútbol", "⚽", "El deporte más popular del mundo", 15),
            Sport("basketball", "Baloncesto", "🏀", "Deporte de canasta", 8),
            Sport("tennis", "Tenis", "🎾", "Deporte de raqueta", 12),
            Sport("volleyball", "Voleibol", "🏐", "Deporte de red", 6),
            Sport("baseball", "Béisbol", "⚾", "Deporte americano", 4),
            Sport("boxing", "Boxeo", "🥊", "Deporte de combate", 3)
        )
    }
    
    suspend fun getEventsBySport(sportId: String): List<Event> {
        delay(500) // Simular llamada de red
        
        return when (sportId) {
            "football" -> getFootballEvents()
            "basketball" -> getBasketballEvents()
            "tennis" -> getTennisEvents()
            else -> emptyList()
        }
    }
    
    suspend fun getEventById(eventId: String): Event? {
        delay(300)
        return getAllEvents().find { it.id == eventId }
    }
    
    fun getLiveEvents(): Flow<List<Event>> = flow {
        while (true) {
            delay(5000) // Actualizar cada 5 segundos
            val liveEvents = getAllEvents().filter { it.status == EventStatus.LIVE }
            emit(liveEvents)
        }
    }
    
    private fun getFootballEvents(): List<Event> {
        val currentTime = System.currentTimeMillis()
        return listOf(
            Event(
                id = "fb_001",
                sportId = "football",
                homeTeam = "Barcelona SC",
                awayTeam = "Emelec",
                league = "Liga Pro Ecuador",
                startTime = currentTime + 3600000, // 1 hora
                odds = EventOdds(homeWin = 2.1, draw = 3.2, awayWin = 3.8)
            ),
            Event(
                id = "fb_002",
                sportId = "football",
                homeTeam = "Real Madrid",
                awayTeam = "FC Barcelona",
                league = "La Liga",
                startTime = currentTime + 7200000, // 2 horas
                odds = EventOdds(homeWin = 2.5, draw = 3.1, awayWin = 2.9)
            ),
            Event(
                id = "fb_003",
                sportId = "football",
                homeTeam = "Manchester United",
                awayTeam = "Liverpool",
                league = "Premier League",
                startTime = currentTime + 10800000, // 3 horas
                status = EventStatus.LIVE,
                odds = EventOdds(homeWin = 3.2, draw = 3.0, awayWin = 2.3)
            )
        )
    }
    
    private fun getBasketballEvents(): List<Event> {
        val currentTime = System.currentTimeMillis()
        return listOf(
            Event(
                id = "bb_001",
                sportId = "basketball",
                homeTeam = "Lakers",
                awayTeam = "Warriors",
                league = "NBA",
                startTime = currentTime + 5400000,
                odds = EventOdds(homeWin = 1.9, draw = null, awayWin = 1.9)
            ),
            Event(
                id = "bb_002",
                sportId = "basketball",
                homeTeam = "Celtics",
                awayTeam = "Heat",
                league = "NBA",
                startTime = currentTime + 9000000,
                odds = EventOdds(homeWin = 2.1, draw = null, awayWin = 1.7)
            )
        )
    }
    
    private fun getTennisEvents(): List<Event> {
        val currentTime = System.currentTimeMillis()
        return listOf(
            Event(
                id = "tn_001",
                sportId = "tennis",
                homeTeam = "Novak Djokovic",
                awayTeam = "Rafael Nadal",
                league = "ATP Masters",
                startTime = currentTime + 1800000,
                odds = EventOdds(homeWin = 1.8, draw = null, awayWin = 2.0)
            )
        )
    }
    
    private fun getAllEvents(): List<Event> {
        return getFootballEvents() + getBasketballEvents() + getTennisEvents()
    }
}
