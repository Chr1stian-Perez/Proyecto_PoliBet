package com.epn.polibet.data.repository

import com.epn.polibet.data.models.Prediction
import com.epn.polibet.data.models.PredictionStatus
import com.epn.polibet.data.models.PredictionSummary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PredictionsRepository {
    private val _predictions = MutableStateFlow<List<Prediction>>(emptyList())
    val predictions: StateFlow<List<Prediction>> = _predictions.asStateFlow()
    
    private val userPredictions = mutableListOf<Prediction>()
    
    suspend fun createPrediction(prediction: Prediction): Result<Prediction> {
        delay(500) // Simular llamada de red
        
        val newPrediction = prediction.copy(
            id = "pred_${System.currentTimeMillis()}",
            potentialWin = prediction.amount * prediction.odds
        )
        
        userPredictions.add(newPrediction)
        _predictions.value = userPredictions.toList()
        
        return Result.success(newPrediction)
    }
    
    suspend fun getUserPredictions(userId: String): List<Prediction> {
        delay(300)
        return userPredictions.filter { it.userId == userId }
    }
    
    suspend fun getPredictionSummary(userId: String): PredictionSummary {
        delay(300)
        val userPreds = userPredictions.filter { it.userId == userId }
        
        val total = userPreds.size
        val won = userPreds.count { it.status == PredictionStatus.WON }
        val lost = userPreds.count { it.status == PredictionStatus.LOST }
        val pending = userPreds.count { it.status == PredictionStatus.PENDING }
        
        val totalStaked = userPreds.sumOf { it.amount }
        val totalWon = userPreds.filter { it.status == PredictionStatus.WON }
            .sumOf { it.potentialWin }
        
        val winRate = if (total > 0) (won.toDouble() / total) * 100 else 0.0
        
        return PredictionSummary(
            totalPredictions = total,
            wonPredictions = won,
            lostPredictions = lost,
            pendingPredictions = pending,
            totalStaked = totalStaked,
            totalWon = totalWon,
            winRate = winRate
        )
    }
    
    suspend fun cancelPrediction(predictionId: String): Result<Unit> {
        delay(300)
        val index = userPredictions.indexOfFirst { it.id == predictionId }
        if (index != -1) {
            userPredictions[index] = userPredictions[index].copy(status = PredictionStatus.CANCELLED)
            _predictions.value = userPredictions.toList()
            return Result.success(Unit)
        }
        return Result.failure(Exception("Pronóstico no encontrado"))
    }
}
