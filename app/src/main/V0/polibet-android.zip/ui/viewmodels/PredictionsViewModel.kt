package com.epn.polibet.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.epn.polibet.data.models.Prediction
import com.epn.polibet.data.models.PredictionSummary
import com.epn.polibet.data.repository.PredictionsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PredictionsViewModel(
    private val predictionsRepository: PredictionsRepository = PredictionsRepository()
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(PredictionsUiState())
    val uiState: StateFlow<PredictionsUiState> = _uiState.asStateFlow()
    
    fun loadPredictions() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                val userId = "current_user" // En una app real, obtener del AuthViewModel
                val predictions = predictionsRepository.getUserPredictions(userId)
                val summary = predictionsRepository.getPredictionSummary(userId)
                
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    predictions = predictions,
                    summary = summary
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )
            }
        }
    }
    
    fun cancelPrediction(predictionId: String) {
        viewModelScope.launch {
            try {
                predictionsRepository.cancelPrediction(predictionId)
                loadPredictions() // Recargar la lista
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(error = e.message)
            }
        }
    }
}

data class PredictionsUiState(
    val isLoading: Boolean = false,
    val predictions: List<Prediction> = emptyList(),
    val summary: PredictionSummary? = null,
    val error: String? = null
)
