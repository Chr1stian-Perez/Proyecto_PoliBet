package com.epn.polibet.ui.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.epn.polibet.data.models.Event
import com.epn.polibet.data.models.Sport
import com.epn.polibet.data.repository.SportsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DashboardViewModel(
    private val sportsRepository: SportsRepository = SportsRepository()
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()
    
    init {
        loadDashboardData()
    }
    
    private fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            try {
                val sports = sportsRepository.getSports()
                val featuredEvents = getFeaturedEvents()
                
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    sports = sports,
                    featuredEvents = featuredEvents
                )
                
                // Cargar eventos en vivo
                sportsRepository.getLiveEvents().collect { liveEvents ->
                    _uiState.value = _uiState.value.copy(liveEvents = liveEvents)
                }
                
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )
            }
        }
    }
    
    private suspend fun getFeaturedEvents(): List<Event> {
        // Obtener algunos eventos destacados de diferentes deportes
        val footballEvents = sportsRepository.getEventsBySport("football").take(2)
        val basketballEvents = sportsRepository.getEventsBySport("basketball").take(1)
        return footballEvents + basketballEvents
    }
    
    fun refreshData() {
        loadDashboardData()
    }
    
    fun clearError() {
        _uiState.value = _uiState.value.copy(error = null)
    }
}

data class DashboardUiState(
    val isLoading: Boolean = false,
    val sports: List<Sport> = emptyList(),
    val featuredEvents: List<Event> = emptyList(),
    val liveEvents: List<Event> = emptyList(),
    val error: String? = null
)
