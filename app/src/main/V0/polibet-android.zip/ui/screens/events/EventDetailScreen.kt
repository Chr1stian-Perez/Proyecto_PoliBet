package com.epn.polibet.ui.screens.events

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.epn.polibet.data.models.Prediction
import com.epn.polibet.data.models.PredictionType
import com.epn.polibet.ui.components.OddsButton
import com.epn.polibet.ui.components.PoliBetButton
import com.epn.polibet.ui.components.PoliBetTextField
import com.epn.polibet.ui.viewmodels.EventDetailViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventDetailScreen(
    eventId: String,
    onNavigateBack: () -> Unit,
    onCreatePrediction: (Prediction) -> Unit,
    viewModel: EventDetailViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showPredictionDialog by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableStateOf("") }
    var selectedOdds by remember { mutableStateOf(0.0) }
    var predictionType by remember { mutableStateOf(PredictionType.MATCH_RESULT) }
    
    LaunchedEffect(eventId) {
        viewModel.loadEvent(eventId)
    }
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "Detalle del Evento",
                    fontWeight = FontWeight.Bold
                )
            },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                }
            },
            actions = {
                IconButton(onClick = { /* Agregar a favoritos */ }) {
                    Icon(Icons.Default.Star, contentDescription = "Favorito")
                }
            }
        )
        
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            uiState.event?.let { event ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Información del evento
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = event.league,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "${event.homeTeam} vs ${event.awayTeam}",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "Fecha: ${formatEventDateTime(event.startTime)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            
                            Text(
                                text = "Estado: ${event.status.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    
                    // Opciones de apuesta - Resultado del partido
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Resultado del Partido",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OddsButton(
                                    label = event.homeTeam.take(8),
                                    odds = event.odds.homeWin,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        selectedOption = "1"
                                        selectedOdds = event.odds.homeWin
                                        predictionType = PredictionType.MATCH_RESULT
                                        showPredictionDialog = true
                                    }
                                )
                                
                                event.odds.draw?.let { draw ->
                                    OddsButton(
                                        label = "Empate",
                                        odds = draw,
                                        modifier = Modifier.weight(1f),
                                        onClick = {
                                            selectedOption = "X"
                                            selectedOdds = draw
                                            predictionType = PredictionType.MATCH_RESULT
                                            showPredictionDialog = true
                                        }
                                    )
                                }
                                
                                OddsButton(
                                    label = event.awayTeam.take(8),
                                    odds = event.odds.awayWin,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        selectedOption = "2"
                                        selectedOdds = event.odds.awayWin
                                        predictionType = PredictionType.MATCH_RESULT
                                        showPredictionDialog = true
                                    }
                                )
                            }
                        }
                    }
                    
                    // Estadísticas del evento (simuladas)
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "Estadísticas",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly
                            ) {
                                StatColumn(label = "Forma Local", value = "W-W-D")
                                StatColumn(label = "Forma Visitante", value = "L-W-W")
                                StatColumn(label = "H2H", value = "2-1-2")
                            }
                        }
                    }
                    
                    // Información adicional
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = "ℹ️ Información Importante",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text(
                                text = "• Este es un proyecto académico con fines educativos\n" +
                                      "• Los pronósticos son simulados y no involucran dinero real\n" +
                                      "• Las cuotas son generadas automáticamente para demostración",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
    
    // Dialog para crear pronóstico
    if (showPredictionDialog) {
        PredictionDialog(
            eventName = "${uiState.event?.homeTeam} vs ${uiState.event?.awayTeam}",
            selectedOption = selectedOption,
            odds = selectedOdds,
            onDismiss = { showPredictionDialog = false },
            onConfirm = { amount ->
                uiState.event?.let { event ->
                    val prediction = Prediction(
                        id = "",
                        userId = "current_user", // En una app real, obtener del AuthViewModel
                        eventId = event.id,
                        predictionType = predictionType,
                        selectedOption = selectedOption,
                        odds = selectedOdds,
                        amount = amount,
                        potentialWin = amount * selectedOdds
                    )
                    onCreatePrediction(prediction)
                    showPredictionDialog = false
                }
            }
        )
    }
}

@Composable
fun StatColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun PredictionDialog(
    eventName: String,
    selectedOption: String,
    odds: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var amount by remember { mutableStateOf("") }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Crear Pronóstico")
        },
        text = {
            Column {
                Text(
                    text = eventName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "Selección: $selectedOption",
                    style = MaterialTheme.typography.bodyMedium
                )
                
                Text(
                    text = "Cuota: $odds",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                PoliBetTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = "Cantidad a apostar",
                    modifier = Modifier.fillMaxWidth()
                )
                
                if (amount.toDoubleOrNull() != null) {
                    val potentialWin = amount.toDouble() * odds
                    Text(
                        text = "Ganancia potencial: $${String.format("%.2f", potentialWin)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        },
        confirmButton = {
            PoliBetButton(
                onClick = {
                    amount.toDoubleOrNull()?.let { amountValue ->
                        if (amountValue > 0) {
                            onConfirm(amountValue)
                        }
                    }
                },
                enabled = amount.toDoubleOrNull()?.let { it > 0 } == true
            ) {
                Text("Confirmar")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

private fun formatEventDateTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
