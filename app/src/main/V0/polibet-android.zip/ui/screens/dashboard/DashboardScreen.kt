package com.epn.polibet.ui.screens.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.epn.polibet.ui.components.*
import com.epn.polibet.ui.viewmodels.AuthViewModel
import com.epn.polibet.ui.viewmodels.DashboardViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToSports: (String) -> Unit,
    onNavigateToPredictions: () -> Unit,
    onNavigateToProfile: () -> Unit,
    dashboardViewModel: DashboardViewModel = viewModel(),
    authViewModel: AuthViewModel = viewModel()
) {
    val uiState by dashboardViewModel.uiState.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()
    
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        // Top App Bar
        TopAppBar(
            title = {
                Column {
                    Text(
                        text = "¡Hola, ${currentUser?.username ?: "Usuario"}!",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Balance: $${currentUser?.balance ?: 0.0}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            actions = {
                IconButton(onClick = onNavigateToPredictions) {
                    Icon(Icons.Default.List, contentDescription = "Mis Pronósticos")
                }
                IconButton(onClick = onNavigateToProfile) {
                    Icon(Icons.Default.Person, contentDescription = "Perfil")
                }
            }
        )
        
        if (uiState.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Eventos en vivo
                if (uiState.liveEvents.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "🔴 En Vivo",
                            subtitle = "${uiState.liveEvents.size} eventos"
                        )
                    }
                    
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp)
                        ) {
                            items(uiState.liveEvents) { event ->
                                LiveEventCard(
                                    event = event,
                                    onClick = { onNavigateToSports(event.sportId) }
                                )
                            }
                        }
                    }
                }
                
                // Deportes disponibles
                item {
                    SectionHeader(
                        title = "Deportes",
                        subtitle = "Explora todas las categorías"
                    )
                }
                
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        items(uiState.sports) { sport ->
                            SportCard(
                                sport = sport,
                                onClick = { onNavigateToSports(sport.id) }
                            )
                        }
                    }
                }
                
                // Eventos destacados
                if (uiState.featuredEvents.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "Eventos Destacados",
                            subtitle = "Los más populares"
                        )
                    }
                    
                    items(uiState.featuredEvents) { event ->
                        FeaturedEventCard(
                            event = event,
                            onClick = { onNavigateToSports(event.sportId) }
                        )
                    }
                }
                
                // Estadísticas rápidas
                item {
                    QuickStatsCard(
                        onNavigateToPredictions = onNavigateToPredictions
                    )
                }
            }
        }
    }
}
